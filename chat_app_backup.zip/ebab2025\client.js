// client.js - Handles all client-side logic, including file upload and real-time read receipts.

// Performance Optimization: Defer socket initialization
let socket = null;

// Initialize socket with performance optimizations
function initializeSocket() {
    socket = io({
        reconnection: true,
        reconnectionAttempts: Infinity,
        reconnectionDelay: 1000,
        reconnectionDelayMax: 5000,
        timeout: 20000,
        transports: ["websocket", "polling"],
        forceNew: false
    });
    
    // Socket connection event handlers
    socket.on('connect', () => {
        console.log('Connected to server');
        updateLoadingText('Connected!');
        updateConnectionStatus('connected');
        enableMessageInput();
    });
    
    socket.on('disconnect', (reason) => {
        console.log('Disconnected:', reason);
        showLoadingScreen('Disconnected. Reconnecting...');
        updateConnectionStatus('disconnected');
        disableMessageInput();
    });
    
    socket.on('connect_error', (error) => {
        console.error('Connection error:', error);
        showLoadingScreen('Connection failed. Retrying...');
        updateConnectionStatus('error');
    });
    
    socket.on('reconnecting', (attemptNumber) => {
        console.log('Reconnecting attempt:', attemptNumber);
        updateLoadingText(`Reconnecting... (${attemptNumber})`);
        updateConnectionStatus('reconnecting');
    });
    
    socket.on('reconnect', (attemptNumber) => {
        console.log('Reconnected after', attemptNumber, 'attempts');
        hideLoadingScreen();
        updateConnectionStatus('connected');
        enableMessageInput();
    });
}
let currentUser = null;
let pendingHistory = null;
let latestPresenceData = null;
let presenceTickerId = null;
let localOfflineStart = {};
const OFFLINE_KEY_PREFIX = 'offlineStart_';
const SELECTED_USER_KEY = 'selectedUser';
let lastActivityTs = Date.now();
let windowFocused = true;
let pendingReadIds = new Set();
let readFlushTimer = null;

function getStoredOfflineStart(uid) {
    try {
        return localStorage.getItem(OFFLINE_KEY_PREFIX + uid);
    } catch (_) {
        return null;
    }
}

function setStoredOfflineStart(uid, ts) {
    try {
        localStorage.setItem(OFFLINE_KEY_PREFIX + uid, ts);
    } catch (_) {}
}

function clearStoredOfflineStart(uid) {
    try {
        localStorage.removeItem(OFFLINE_KEY_PREFIX + uid);
    } catch (_) {}
}

// --- DOM Elements ---
const messages = document.getElementById('messages');
const form = document.getElementById('form');
const input = document.getElementById('input');
const sendButton = document.getElementById('send-button');
const selectionScreen = document.getElementById('initial-user-selection');
const chatContainer = document.getElementById('chat-container');
const currentUserDisplay = document.getElementById('my-user-id-display');
const otherUserStatus = document.getElementById('other-user-status');
const otherUserName = document.getElementById('other-user-name');
const photoInput = document.getElementById('photo-input');
const photoButton = document.getElementById('photo-button');
const loadingScreen = document.getElementById('loading-screen');
const loadingText = document.getElementById('loading-text');
let typingTimeout = null;
let lastInputHeightPx = null;

// --- Loading Screen Functions ---

function showLoadingScreen(text = 'Loading...') {
    if (loadingScreen) {
        loadingText.textContent = text;
        loadingScreen.classList.remove('hidden');
    }
}

function hideLoadingScreen() {
    if (loadingScreen) {
        loadingScreen.classList.add('hidden');
    }
}

function updateLoadingText(text) {
    if (loadingText) {
        loadingText.textContent = text;
    }
}

// --- Connection Status Functions ---

function updateConnectionStatus(status) {
    const statusElement = document.getElementById('connection-status');
    if (!statusElement) return;
    
    const dot = statusElement.querySelector('.status-dot');
    const text = statusElement.querySelector('.status-text');
    
    // Remove all status classes
    dot.className = 'status-dot';
    
    switch(status) {
        case 'connected':
            dot.classList.add('connected');
            text.textContent = 'Connected';
            break;
        case 'disconnected':
            dot.classList.add('disconnected');
            text.textContent = 'Disconnected';
            break;
        case 'reconnecting':
            dot.classList.add('reconnecting');
            text.textContent = 'Reconnecting...';
            break;
        case 'error':
            dot.classList.add('error');
            text.textContent = 'Connection Error';
            break;
        default:
            text.textContent = 'Connecting...';
    }
}

function enableMessageInput() {
    if (input) input.disabled = false;
    if (sendButton) sendButton.disabled = false;
    if (sendButton) sendButton.style.opacity = '1';
}

function disableMessageInput() {
    if (input) input.disabled = true;
    if (sendButton) sendButton.disabled = true;
    if (sendButton) sendButton.style.opacity = '0.5';
}


// --- Utility Functions ---

function getCurrentTime() {
    return new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
}

function getClockTime(timestamp) {
    const d = timestamp ? new Date(timestamp) : new Date();
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
}

function getDateKey(timestamp) {
    const d = timestamp ? new Date(timestamp) : new Date();
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
}

function getDateLabel(timestamp) {
    const d = timestamp ? new Date(timestamp) : new Date();
    const now = new Date();
    const todayKey = getDateKey(now.toISOString());
    const yest = new Date(now);
    yest.setDate(now.getDate() - 1);
    const yesterdayKey = getDateKey(yest.toISOString());
    const key = getDateKey(d.toISOString());
    
    if (key === todayKey) return 'Today';
    if (key === yesterdayKey) return 'Yesterday';
    
    // For messages within the last 6 days, show day name
    const sixDaysAgo = new Date(now);
    sixDaysAgo.setDate(now.getDate() - 6);
    
    if (d > sixDaysAgo) {
        return d.toLocaleDateString(undefined, { weekday: 'long' });
    }
    
    // For older messages, show full date (MM/DD/YYYY format)
    return d.toLocaleDateString(undefined, { 
        year: 'numeric', 
        month: '2-digit', 
        day: '2-digit' 
    });
}

function ensureDateStamp(timestamp) {
    const key = getDateKey(timestamp);
    if (!messages.querySelector(`li.date-separator[data-date="${key}"]`)) {
        const li = document.createElement('li');
        li.className = 'date-separator';
        li.dataset.date = key;
        li.textContent = getDateLabel(timestamp);
        messages.appendChild(li);
    }
}

function scrollToBottom() {
    const threshold = 80;
    const distance = messages.scrollHeight - messages.scrollTop - messages.clientHeight;
    if (distance < threshold) {
        messages.scrollTop = messages.scrollHeight;
    }
}

function forceScrollToBottom() {
    messages.scrollTop = messages.scrollHeight;
}

function updateStatusUI(id, status) {
    const listItem = document.querySelector(`li[data-id="${String(id)}"]`);
    if (!listItem) return;
    const statusSpan = listItem.querySelector('.message-time .status-sent, .message-time .status-delivered, .message-time .status-read');
    if (!statusSpan) return;
    statusSpan.classList.remove('status-sent');
    statusSpan.classList.remove('status-delivered');
    statusSpan.classList.remove('status-read');
    if (status === 'read') {
        statusSpan.classList.add('status-read');
        statusSpan.innerHTML = '\u2713\u2713';
    } else if (status === 'delivered') {
        statusSpan.classList.add('status-delivered');
        statusSpan.innerHTML = '\u2713\u2713';
    } else {
        statusSpan.classList.add('status-sent');
        statusSpan.innerHTML = '\u2713';
    }
}

function getTimeAgo(timestamp) {
    if (!timestamp) return null;
    const now = new Date();
    const past = new Date(timestamp);
    const diffMs = now - past;
    const diffSeconds = Math.floor(diffMs / 1000);
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    if (diffSeconds < 30) return 'just now';
    if (diffSeconds < 60) return 'less than a minute ago';
    if (diffMins < 60) return `${diffMins} minute${diffMins > 1 ? 's' : ''} ago`;
    if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
}

function getOfflineDuration(timestamp) {
    if (!timestamp) return null;
    const now = new Date();
    const past = new Date(timestamp);
    const diffMs = now - past;
    const mins = Math.floor(diffMs / 60000);
    const hours = Math.floor(diffMs / 3600000);
    const days = Math.floor(diffMs / 86400000);
    if (mins < 1) return '<1m';
    if (days >= 1) {
        const remHours = hours % 24;
        return remHours ? `${days}d ${remHours}h` : `${days}d`;
    }
    if (hours >= 1) {
        const remMins = mins % 60;
        return remMins ? `${hours}h ${remMins}m` : `${hours}h`;
    }
    return `${mins}m`;
}

function updatePresenceDisplays() {
    if (!latestPresenceData) return;
    if (currentUser) {
        const otherUser = currentUser === 'i' ? 'x' : 'i';
        const otherPresence = latestPresenceData[otherUser];
        if (otherPresence) {
            if (otherPresence.isOnline) {
                otherUserStatus.textContent = 'Online';
                otherUserStatus.className = 'status-online';
            } else {
                const durationText = otherPresence.lastSeen ? (getOfflineDuration(otherPresence.lastSeen) || 'unknown') : 'unknown';
                otherUserStatus.textContent = `Offline ${durationText}`;
                otherUserStatus.className = 'status-offline';
            }
        }
    }

    const userButtons = document.querySelectorAll('.user-buttons button');
    userButtons.forEach(button => {
        const userId = button.getAttribute('data-user');
        const userPresence = latestPresenceData[userId];
        if (userPresence && !userPresence.isOnline) {
            const originalText = button.getAttribute('data-original-text') || button.textContent;
            if (!button.getAttribute('data-original-text')) {
                button.setAttribute('data-original-text', originalText);
            }
            const durationTextBtn = userPresence.lastSeen ? (getOfflineDuration(userPresence.lastSeen) || 'unknown') : 'unknown';
            if (userId !== currentUser) {
                button.textContent = `${originalText} (offline ${durationTextBtn})`;
            }
        }
        if (userPresence && userPresence.isOnline) {
            const originalText = button.getAttribute('data-original-text') || button.textContent;
            button.textContent = originalText;
        }
    });
}

// --- Read Receipt Trigger (NEW) ---
function triggerReadReceipt(messageData) {
    if (document.visibilityState !== 'visible' || !windowFocused) return;
    if (messageData.senderID !== currentUser && messageData._id) {
        socket.emit('message read', { 
            readerID: currentUser,
            messageID: messageData._id 
        });
    }
}

// --- File Upload Logic ---
if (photoInput) {
    photoInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            uploadFile(file);
        }
        e.target.value = null;
    });
}

async function uploadFile(file) {
    if (!currentUser) return alert('Please select a user first.');

    chatContainer.style.cursor = 'progress'; 

    const formData = new FormData();
    formData.append('mediaFile', file); 

    try {
        const response = await fetch('/upload', { method: 'POST', body: formData });
        if (!response.ok) throw new Error('Upload failed with status: ' + response.status);
        const data = await response.json(); 

        const messageData = {
            senderID: currentUser,
            message: data.url,
            type: data.type,
            timestamp: new Date().toISOString()
        };
        socket.emit('chat message', messageData);

    } catch (error) {
        console.error('File upload failed:', error);
        alert('File upload failed. See console for details.');
    } finally {
        chatContainer.style.cursor = 'default';
    }
}


// --- Message Rendering Logic (UPDATED FOR STATUS) ---

function createMessageElement(messageData) {
    const senderKey = messageData.senderID || messageData.sender;
    const isMyMessage = senderKey === currentUser;
    const status = messageData.status || 'sent'; // Default status to 'sent' if missing

    const li = document.createElement('li');
    li.className = `message-bubble ${isMyMessage ? 'my-message' : 'their-message'}`;
    // Use the MongoDB ID to target for status updates later
    if (messageData._id) {
        li.dataset.id = String(messageData._id);
    }

    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';

    // --- Media/Text Content Rendering ---
    if (messageData.type === 'image') {
        const img = document.createElement('img');
        img.src = messageData.message; 
        // ... (styles)
        contentDiv.appendChild(img);
    } 
    // ... (logic for video and document remains the same)
    else if (messageData.type === 'video') {
        const video = document.createElement('video');
        video.src = messageData.message;
        video.controls = true;
        // ... (styles)
        contentDiv.appendChild(video);
    } else if (messageData.type === 'document') {
        const docLink = document.createElement('a');
        docLink.href = messageData.message;
        docLink.target = '_blank';
        docLink.textContent = `\ud83d\udcc4 Download File (${messageData.message.split('/').pop()})`; 
        // ... (styles)
        contentDiv.appendChild(docLink);
    } else {
        const textSpan = document.createElement('span');
        textSpan.className = 'message-text';
        const msg = String(messageData.message || '');
        const frag = document.createDocumentFragment();
        const urlRegex = /(https?:\/\/[^\s]+)/g;
        let lastIndex = 0;
        let match;
        while ((match = urlRegex.exec(msg)) !== null) {
            const url = match[1];
            if (match.index > lastIndex) frag.appendChild(document.createTextNode(msg.slice(lastIndex, match.index)));
            const a = document.createElement('a');
            a.href = url;
            a.target = '_blank';
            a.rel = 'noopener noreferrer';
            a.textContent = url;
            frag.appendChild(a);
            lastIndex = match.index + url.length;
        }
        if (lastIndex < msg.length) frag.appendChild(document.createTextNode(msg.slice(lastIndex)));
        textSpan.appendChild(frag);
        contentDiv.appendChild(textSpan);
    }

    li.appendChild(contentDiv); 

    // Time and Status Container
    const timeSpan = document.createElement('span');
    timeSpan.className = 'message-time';
    const timeTextSpan = document.createElement('span');
    timeTextSpan.className = 'time-text';
    const ts = messageData.timestamp || new Date().toISOString();
    timeTextSpan.textContent = getClockTime(ts);
    timeSpan.appendChild(timeTextSpan);

    // --- Status Checkmarks (NEW LOGIC) ---
    if (isMyMessage) {
        const statusSpan = document.createElement('span');
        statusSpan.classList.add(`status-${status}`); 

        if (status === 'read') {
            statusSpan.innerHTML = '\u2713\u2713'; // Double checkmark
        } else if (status === 'delivered') {
            statusSpan.innerHTML = '\u2713\u2713'; // Double grey checks for delivered
        } else {
            statusSpan.innerHTML = '\u2713';  // Single checkmark (Default for sent)
        }

        timeSpan.appendChild(statusSpan);
    }

    li.appendChild(timeSpan);
    
    li.dataset.timestamp = ts;

    return li;
}

function renderMessage(messageData) {
    const ts = messageData.timestamp || new Date().toISOString();
    ensureDateStamp(ts);
    messages.appendChild(createMessageElement(messageData));
    scrollToBottom();
    const senderKey = messageData.senderID || messageData.sender;
    const isIncoming = senderKey !== currentUser;
    if (isIncoming && messageData._id && messageData.status !== 'read') {
        const li = messages.querySelector(`li[data-id="${messageData._id}"]`);
        if (li) observeForRead(li, messageData);
    }
}

// --- Socket.IO Event Listeners ---
socket.on('chat message', (msg) => {
    // Check if a list item with this ID already exists (prevents duplicates when sender receives own msg)
    if (!document.querySelector(`li[data-id="${String(msg._id)}"]`)) {
        renderMessage(msg);
    }
    lastActivityTs = Date.now();
    // Immediate presence reflection for other user activity
    if (currentUser) {
        const otherUser = currentUser === 'i' ? 'x' : 'i';
        if ((msg.senderID || msg.sender) === otherUser) {
            otherUserStatus.textContent = 'Online';
            otherUserStatus.className = 'status-online';
            clearStoredOfflineStart(otherUser);
            delete localOfflineStart[otherUser];
            // Receiver acknowledges delivery once bubble is rendered
            if (msg._id) {
                socket.emit('message delivered', {
                    messageID: msg._id,
                    senderID: msg.senderID || msg.sender
                });
            }
        }
    }
});

socket.on('history', (messagesHistory) => {
    if (!currentUser) {
        pendingHistory = messagesHistory;
        console.log('History received but pending user selection:', messagesHistory.length, 'messages');
        return;
    }
    lastActivityTs = Date.now();
    messagesHistory.sort((a, b) => {
        const ta = new Date(a.timestamp || 0).getTime();
        const tb = new Date(b.timestamp || 0).getTime();
        return ta - tb;
    });
    const deliverIds = [];
    messagesHistory.forEach(msg => {
        if (!document.querySelector(`li[data-id="${msg._id}"]`)) {
            renderMessage(msg);
        }
        const isIncoming = (msg.senderID || msg.sender) !== currentUser;
        if (isIncoming && msg.status === 'sent' && msg._id) {
            deliverIds.push(msg._id);
        }
    });
    forceScrollToBottom();
    if (currentUser) {
        const otherUser = currentUser === 'i' ? 'x' : 'i';
        if (deliverIds.length > 0) {
            socket.emit('messages delivered', { messageIDs: deliverIds, senderID: otherUser });
        }
        socket.emit('mark conversation read', { readerID: currentUser });
    }
});

// --- Real-time Status Update Listener (NEW) ---
socket.on('message status update', (data) => {
    if (data.status === 'read') updateStatusUI(data.messageID, 'read');
});

// Delivered update (receiver online)
socket.on('message delivered', (data) => {
    updateStatusUI(data.messageID, 'delivered');
});


   



// --- Event Handlers ---

form.addEventListener('submit', (e) => {
    e.preventDefault();
    if (input.value.trim() && currentUser) {
        const messageData = {
            senderID: currentUser, 
            message: input.value,
            type: 'text',
            status: 'sent', // Explicitly set status to sent
            timestamp: new Date().toISOString()
        };

        socket.emit('chat message', messageData);
        socket.emit('mark conversation read', { readerID: currentUser });
        input.value = '';
        if (lastInputHeightPx) {
            input.style.height = lastInputHeightPx;
        }
        if (sendButton) sendButton.disabled = true;
        input.focus();
    }
});

input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        if (input.value.trim()) {
            form.dispatchEvent(new Event('submit', { cancelable: true }));
        }
    }
});

input.addEventListener('input', () => {
    input.style.height = 'auto';
    const maxH = 160;
    input.style.height = Math.min(input.scrollHeight, maxH) + 'px';
    lastInputHeightPx = input.style.height;
    if (sendButton) sendButton.disabled = input.value.trim().length === 0;
    if (currentUser) {
        socket.emit('typing', { userID: currentUser, isTyping: true });
        if (typingTimeout) clearTimeout(typingTimeout);
        typingTimeout = setTimeout(() => {
            socket.emit('typing', { userID: currentUser, isTyping: false });
        }, 1200);
    }
});

input.addEventListener('keypress', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        if (input.value.trim()) {
            form.dispatchEvent(new Event('submit', { cancelable: true }));
        }
    }
});

// --- User Selection Functionality ---
function setupUserSelection() {
    const userButtons = document.querySelectorAll('.user-buttons button');

    userButtons.forEach(button => {
        button.addEventListener('click', () => {
            const selectedUser = button.getAttribute('data-user');
            selectUser(selectedUser);
        });
    });
}

function selectUser(userId) {
    currentUser = userId;

    // Tell the server which user we are
    socket.emit('select user', userId);
}

socket.on('user selected', (success) => {
    if (success) {
        selectionScreen.style.display = 'none';
        chatContainer.style.display = 'flex';
        currentUserDisplay.textContent = currentUser;
        
        // Set the other user's name
        const otherUser = currentUser === 'i' ? 'x' : 'i';
        otherUserName.textContent = otherUser.toUpperCase();
        setStoredSelectedUser(currentUser);
        
        input.focus();

        // Render pending history now that we know who the current user is
        if (pendingHistory && pendingHistory.length > 0) {
            console.log('Rendering pending history for user:', currentUser);
            pendingHistory.forEach(renderMessage);
            pendingHistory = null; // Clear pending history
            forceScrollToBottom();
        }

        // Request latest presence data
        socket.emit('get presence update');
    } else {
        alert('This user is already taken. Please select the other user.');
        clearStoredSelectedUser();
        selectionScreen.style.display = 'flex';
        chatContainer.style.display = 'none';
    }
});

function updateOtherUserStatus() {
    // Logic to update the other user's status display
    socket.emit('get available users');
}

socket.on('available users', (inUseList) => {
    console.log('Available users:', inUseList);

    // Enable/disable buttons based on availability
    const userButtons = document.querySelectorAll('.user-buttons button');
    userButtons.forEach(button => {
        const userId = button.getAttribute('data-user');
        button.disabled = inUseList.includes(userId) && userId !== currentUser;
    });
});

socket.on('typing', (data) => {
    if (!currentUser) return;
    const otherUser = currentUser === 'i' ? 'x' : 'i';
    if (data.userID === otherUser) {
        if (data.isTyping) {
            otherUserStatus.textContent = 'Typing…';
            otherUserStatus.className = 'status-typing';
        } else {
            updatePresenceDisplays();
        }
    }
});

// --- Enhanced Presence Update Handler ---
socket.on('presence update', (presenceData) => {
    console.log('Presence update received:', presenceData);
    latestPresenceData = presenceData;
    for (const uid in presenceData) {
        const p = presenceData[uid];
        if (p.isOnline) {
            delete localOfflineStart[uid];
            clearStoredOfflineStart(uid);
        } else {
            // rely exclusively on server-provided lastSeen for offline duration
            if (p.lastSeen) {
                localOfflineStart[uid] = p.lastSeen;
                setStoredOfflineStart(uid, p.lastSeen);
            }
        }
    }
    updatePresenceDisplays();
    lastActivityTs = Date.now();
    if (!presenceTickerId) {
        presenceTickerId = setInterval(() => {
            updatePresenceDisplays();
            updateMessageTimestamps();
            socket.emit('get presence update');
        }, 10000);
    }
});

// Photo button click handler
if (photoButton && photoInput) {
    photoButton.addEventListener('click', () => {
        photoInput.click();
    });
}

// Initialize user selection when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    ['i','x'].forEach(uid => {
        const stored = getStoredOfflineStart(uid);
        if (stored) localOfflineStart[uid] = stored;
    });
    
    // Performance: Initialize socket first
    initializeSocket();
    
    // Show connecting state
    showLoadingScreen('Connecting...');
    
    // Wait for socket to be ready before setting up UI
    setTimeout(() => {
        setupUserSelection();
        const storedUser = getStoredSelectedUser();
        if (storedUser) {
            currentUser = storedUser;
            selectionScreen.style.display = 'none';
            chatContainer.style.display = 'flex';
            currentUserDisplay.textContent = currentUser;
            const otherUser = currentUser === 'i' ? 'x' : 'i';
            otherUserName.textContent = otherUser.toUpperCase();
            socket.emit('select user', currentUser);
            socket.emit('get presence update');
            socket.emit('get history');
            socket.emit('mark conversation read', { readerID: currentUser });
        } else {
            // Hide loading screen if user needs to select
            hideLoadingScreen();
        }
        
        if (!presenceTickerId) {
            presenceTickerId = setInterval(() => {
                updatePresenceDisplays();
                updateMessageTimestamps();
                socket.emit('get presence update');
            }, 10000);
        }
    startRefreshWatchdog();
    window.addEventListener('focus', () => { windowFocused = true; });
    window.addEventListener('blur', () => { windowFocused = false; });
    document.addEventListener('visibilitychange', () => { updatePresenceDisplays(); });
});

function startRefreshWatchdog() {
    setInterval(() => {
        const disconnected = socket.disconnected;
        const stale = Date.now() - lastActivityTs > 120000; // >2 minutes without activity
        if (disconnected) {
            try { socket.connect(); } catch (_) {}
        }
        if (stale) {
            socket.emit('get presence update');
            socket.emit('get history');
            updatePresenceDisplays();
            updateMessageTimestamps();
        }
    }, 30000);
}

function observeForRead(li, messageData) {
    const id = messageData._id;
    if (!id) return;
    if (li.dataset.readObserved === '1') return;
    const io = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
            if (entry.isIntersecting && document.visibilityState === 'visible' && windowFocused) {
                pendingReadIds.add(id);
                if (!readFlushTimer) {
                    readFlushTimer = setTimeout(() => {
                        const ids = Array.from(pendingReadIds);
                        pendingReadIds.clear();
                        readFlushTimer = null;
                        if (ids.length > 0) {
                            socket.emit('messages read', { readerID: currentUser, messageIDs: ids });
                        }
                    }, 250);
                }
                io.disconnect();
                li.dataset.readObserved = '1';
            }
        });
    }, { threshold: 0.3 });
    io.observe(li);
}

socket.on('reconnect', () => {
    if (currentUser) {
        socket.emit('select user', currentUser);
        socket.emit('get presence update');
        socket.emit('get history');
    }
    hideLoadingScreen();
});

// --- Timestamp Ticker for Message Bubbles ---
function updateMessageTimestamps() {
    const items = document.querySelectorAll('li.message-bubble');
    items.forEach(li => {
        const ts = li.dataset.timestamp;
        const timeTextEl = li.querySelector('.message-time .time-text');
        if (ts && timeTextEl) {
            timeTextEl.textContent = getClockTime(ts);
        }
    });
}
function getStoredSelectedUser() {
    try {
        return localStorage.getItem(SELECTED_USER_KEY);
    } catch (_) { return null; }
}

function setStoredSelectedUser(uid) {
    try { localStorage.setItem(SELECTED_USER_KEY, uid); } catch (_) {}
}

function clearStoredSelectedUser() {
    try { localStorage.removeItem(SELECTED_USER_KEY); } catch (_) {}
}
